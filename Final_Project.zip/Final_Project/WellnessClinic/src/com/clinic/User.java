package com.clinic;


//User Model Class
//Contains fields corresponding to the attributes of User entity in Database 
public class User {
  private int userId;
  private String email;
  private String pwd;
  private String fullname;
  private int roleId; 
  
  public User() {};
  
  public User( String email , String pwd , String fullname, int roleId)
	{
	this.email = email;
	this.pwd = pwd;
	this.fullname = fullname;
	this.roleId = roleId;
	}
  
  //Setters
  public void setuserId(int userId) {
		this.userId = userId;
	}
	public void setfullname(String fullname) {
		this.fullname = fullname;		
	}
	public void setemail(String email) {
		this.email = email;
	}
	
	public void setpwd(String pwd) {
		this.pwd = pwd;
	}
	
	public void setroleId(int roleId) {
		this.roleId = roleId;
	}
	
	//Getters
    public int getuserId() {
        return userId;
    }

    public String getemail() {
        return email;
    }

    public String getpwd() {
        return pwd;
    }
    
    public String getfullname() {
        return fullname;
    }
    
    public int getroleId() {
        return roleId;
    }
}