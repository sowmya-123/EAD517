package com.clinic;

public class Admin {

}
